// Hai joystick ảo (trái = di chuyển, phải = xoay camera) + nút cảm ứng + bàn phím dự phòng
export function initControls(G) {
  const C = { mx: 0, my: 0, lx: 0, ly: 0, held: {}, pressed: {} };
  const R = 58;

  function stick(zoneId, cb) {
    const z = document.getElementById(zoneId);
    const base = z.querySelector('.base'), knob = z.querySelector('.knob');
    let pid = null, ox = 0, oy = 0;
    const place = (el, x, y) => { el.style.left = x + 'px'; el.style.top = y + 'px'; };
    z.addEventListener('pointerdown', e => {
      if (pid !== null) return;
      pid = e.pointerId; z.setPointerCapture(pid);
      const r = z.getBoundingClientRect();
      ox = e.clientX; oy = e.clientY;
      base.style.display = knob.style.display = 'block';
      place(base, ox - r.left, oy - r.top); place(knob, ox - r.left, oy - r.top);
      e.preventDefault();
    });
    z.addEventListener('pointermove', e => {
      if (e.pointerId !== pid) return;
      let dx = e.clientX - ox, dy = e.clientY - oy;
      const len = Math.hypot(dx, dy);
      if (len > R) { dx = dx / len * R; dy = dy / len * R; }
      const r = z.getBoundingClientRect();
      place(knob, ox + dx - r.left, oy + dy - r.top);
      cb(dx / R, dy / R);
    });
    const end = e => {
      if (e.pointerId !== pid) return;
      pid = null; cb(0, 0);
      base.style.display = knob.style.display = 'none';
    };
    z.addEventListener('pointerup', end);
    z.addEventListener('pointercancel', end);
  }
  stick('zoneL', (x, y) => { C.mx = x; C.my = y; });
  stick('zoneR', (x, y) => { C.lx = x; C.ly = y; });

  document.querySelectorAll('[data-act]').forEach(b => {
    const act = b.dataset.act;
    b.addEventListener('pointerdown', e => {
      C.held[act] = true; C.pressed[act] = true; b.classList.add('on');
      b.setPointerCapture(e.pointerId); e.preventDefault();
    });
    const up = () => { C.held[act] = false; b.classList.remove('on'); };
    b.addEventListener('pointerup', up);
    b.addEventListener('pointercancel', up);
  });

  // Bàn phím (để thử trên máy tính nếu cần)
  const keys = {};
  const map = { Space: 'jump', KeyJ: 'attack', KeyK: 'spell', KeyG: 'glide', KeyE: 'grapple', KeyH: 'heal', KeyI: 'menu' };
  addEventListener('keydown', e => {
    keys[e.code] = true;
    const a = map[e.code];
    if (a && !C.held[a]) { C.pressed[a] = true; }
    if (a) C.held[a] = true;
  });
  addEventListener('keyup', e => { keys[e.code] = false; const a = map[e.code]; if (a) C.held[a] = false; });

  let kbMove = false, kbLook = false;
  C.poll = () => {
    const m = keys.KeyW || keys.KeyS || keys.KeyA || keys.KeyD;
    if (m) { C.mx = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0); C.my = (keys.KeyS ? 1 : 0) - (keys.KeyW ? 1 : 0); kbMove = true; }
    else if (kbMove) { C.mx = C.my = 0; kbMove = false; }
    const l = keys.ArrowLeft || keys.ArrowRight || keys.ArrowUp || keys.ArrowDown;
    if (l) { C.lx = (keys.ArrowRight ? 1 : 0) - (keys.ArrowLeft ? 1 : 0); C.ly = (keys.ArrowDown ? 1 : 0) - (keys.ArrowUp ? 1 : 0); kbLook = true; }
    else if (kbLook) { C.lx = C.ly = 0; kbLook = false; }
  };
  C.press = a => { const v = C.pressed[a]; C.pressed[a] = false; return !!v; };
  return C;
}
