import * as THREE from 'three';
import { createAudio } from './audio.js';
import { initControls } from './controls.js';
import { createRPG } from './rpg_system.js';
import { createWorld } from './world.js';
import { createPlayer } from './player.js';
import { createCombat } from './combat.js';
import { createEnemies } from './enemies.js';
import { createMultiplayer } from './multiplayer.js';

const $ = id => document.getElementById(id);
const G = { THREE, $, started: false, time: 0.2, mode: 'single', isNight: false };
G.audio = createAudio();
G.rpg = createRPG(G);
G.mp = createMultiplayer(G);
G.toast = msg => {
  const box = $('toast'), d = document.createElement('div');
  d.textContent = msg; box.appendChild(d);
  while (box.children.length > 4) box.removeChild(box.firstChild);
  setTimeout(() => d.remove(), 2600);
};

const hasSave = G.rpg.load();
const newSeed = () => Math.floor(Math.random() * 2147483647);
const msg = t => { $('menuMsg').textContent = t || ''; };

$('bSingle').onclick = () => {
  G.audio.init(); G.mode = 'single';
  start(hasSave && G.rpg.d.seed ? G.rpg.d.seed : newSeed());
};
$('bHost').onclick = async () => {
  G.audio.init(); msg('Đang tạo phòng...');
  const seed = newSeed();
  try { const code = await G.mp.host(seed); G.mode = 'host'; start(seed); G.toast('Mã phòng: ' + code + ' (chia sẻ cho bạn bè)'); G.roomCode = code; }
  catch (e) { msg(e.message); }
};
$('bJoin').onclick = async () => {
  const code = $('code').value.trim();
  if (code.length < 3) return msg('Nhập mã phòng');
  G.audio.init(); msg('Đang kết nối...');
  try { const seed = await G.mp.join(code); G.mode = 'client'; start(seed); G.toast('Đã vào phòng ' + code.toUpperCase()); }
  catch (e) { msg(e.message); }
};
$('bReset').onclick = () => { G.rpg.wipe(); msg('Đã xóa dữ liệu. Tải lại ứng dụng để bắt đầu mới.'); };

function start(seed) {
  $('menu').classList.add('hidden'); $('hud').classList.remove('hidden');
  const renderer = new THREE.WebGLRenderer({ canvas: $('gl'), antialias: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x87c4ee, 40, 170);
  const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.3, 400);
  const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x405030, 0.8); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff0d0, 1); sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  Object.assign(sun.shadow.camera, { left: -45, right: 45, top: 45, bottom: -45, near: 1, far: 260 });
  sun.shadow.bias = -0.0008; scene.add(sun, sun.target);
  Object.assign(G, { renderer, scene, camera, hemi, sun });

  G.ctl = initControls(G);
  G.world = createWorld(G, seed);
  G.player = createPlayer(G);
  G.combat = createCombat(G);
  G.enemies = createEnemies(G);

  const D = G.rpg.d;
  if (G.mode === 'single' && D.pos && D.seed === seed) {
    const [x, y, z] = D.pos; if (G.world.heightAt(x, z) > -5) G.player.pos.set(x, y + 1, z);
  }
  D.seed = seed;
  const st = G.rpg.stats(); G.player.hp = st.maxHp; G.player.st = st.maxSt; G.player.mp = st.maxMp;
  G.world.preload(G.player.pos.x, G.player.pos.z);

  addEventListener('resize', () => { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); });
  setInterval(() => { if (G.started) G.rpg.save(); }, 10000);
  document.addEventListener('visibilitychange', () => { if (document.hidden) G.rpg.save(); });

  G.started = true;
  G.toast('Chào mừng đến Shroud Realms! Đánh cây/đá để lấy tài nguyên, mở 🎒 để chế tạo');
  let last = performance.now(), fpsT = 0, fps = 60, frames = 0;
  const skyDay = new THREE.Color(0x87c4ee), skyNight = new THREE.Color(0x060a16), skyDusk = new THREE.Color(0xe0885a), skyShroud = new THREE.Color(0x2b1244), c = new THREE.Color();

  function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    frames++; fpsT += dt; if (fpsT >= 1) { fps = frames; frames = 0; fpsT = 0; }
    const P = G.player;
    G.time = (G.time + dt / 300) % 1;
    G.world.update(P.pos.x, P.pos.z);
    P.update(dt); G.combat.update(dt); G.enemies.update(dt); G.mp.update(dt);

    // Môi trường: ngày/đêm + Shroud
    const ang = G.time * Math.PI * 2, sunH = Math.sin(ang);
    const day = Math.min(1, Math.max(0, (sunH + 0.15) / 0.4)), dusk = 1 - Math.min(1, Math.abs(sunH) / 0.25);
    G.isNight = sunH < 0;
    const s = G.world.shroudAt(P.pos.x, P.pos.z);
    c.copy(skyNight).lerp(skyDay, day).lerp(skyDusk, dusk * 0.55).lerp(skyShroud, s * 0.85);
    scene.background = c; scene.fog.color.copy(c);
    scene.fog.far = 170 - s * 100; scene.fog.near = 40 - s * 25;
    sun.position.set(P.pos.x + Math.cos(ang) * 80, 40 + Math.abs(sunH) * 80, P.pos.z + 40);
    sun.target.position.copy(P.pos);
    sun.intensity = 0.12 + 0.95 * day; hemi.intensity = (0.22 + 0.6 * day) * (1 - 0.35 * s);
    $('shroudFx').style.opacity = Math.min(1, s * 1.2).toFixed(2);
    if (s > 0.3 && !P.dead) P.dot(s * 4 * (1 - G.rpg.stats().resist) * dt);

    // HUD
    const S = G.rpg.stats(), D = G.rpg.d;
    const bar = (f, t, v, m) => { $(f).style.width = Math.max(0, Math.min(100, v / m * 100)) + '%'; $(t).textContent = Math.ceil(Math.max(0, v)) + '/' + m; };
    bar('hpF', 'hpT', P.hp, S.maxHp); bar('stF', 'stT', P.st, S.maxSt); bar('mpF', 'mpT', P.mp, S.maxMp);
    $('xpF').style.width = (D.xp / (D.lvl * 60) * 100) + '%'; $('xpT').textContent = 'Cấp ' + D.lvl + (D.sp ? ' · ' + D.sp + ' điểm KN' : '');
    const hh = Math.floor(((G.time * 24 + 6) % 24)), mm = Math.floor(((G.time * 24 * 60) % 60));
    $('info').innerHTML = String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + (G.isNight ? ' 🌙' : ' ☀️') +
      '<br>Shroud ' + Math.round(s * 100) + '% · ' + fps + ' FPS' +
      (G.mp.active ? '<br>👥 ' + G.mp.count() + '/8' + (G.mp.isHost ? ' · Phòng ' + G.mp.code : '') : '');
    const b = G.enemies.bossNear();
    $('boss').classList.toggle('hidden', !b);
    if (b) { $('bossN').textContent = b.T.name; $('bossF').style.width = Math.max(0, b.hp / b.max * 100) + '%'; }
    G.audio.tick(dt);
    renderer.render(scene, camera);
  }
  requestAnimationFrame(loop);
}
