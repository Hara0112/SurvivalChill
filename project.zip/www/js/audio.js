// Âm thanh tạo hoàn toàn bằng Web Audio API (không cần file)
export function createAudio() {
  let ctx = null, master = null, nbuf = null, musicT = 1;
  const A = {};
  A.init = () => {
    if (ctx) { ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.55; master.connect(ctx.destination);
    nbuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = nbuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  };
  const tone = (f, dur, type = 'sine', vol = 0.2, slide = 0) => {
    if (!ctx) return;
    const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(25, f + slide), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur);
  };
  const noise = (dur, freq, vol = 0.3, q = 1, type = 'bandpass', sweep = 0) => {
    if (!ctx) return;
    const t = ctx.currentTime, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = nbuf; f.type = type; f.Q.value = q; f.frequency.setValueAtTime(freq, t);
    if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(60, freq + sweep), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t, Math.random() * 0.5, dur);
  };
  const S = {
    slash: () => noise(0.2, 3000, 0.3, 0.8, 'bandpass', -2200),
    hit: () => { tone(140, 0.14, 'square', 0.22, -80); noise(0.08, 900, 0.25); },
    chop: () => { tone(220, 0.08, 'triangle', 0.3, -120); noise(0.1, 600, 0.3, 1, 'lowpass'); },
    mine: () => { tone(900, 0.07, 'square', 0.15, -500); noise(0.06, 3500, 0.2, 2, 'highpass'); },
    pickup: () => { tone(660, 0.09, 'sine', 0.15); setTimeout(() => tone(990, 0.12, 'sine', 0.15), 70); },
    hurt: () => { tone(180, 0.25, 'sawtooth', 0.25, -110); noise(0.15, 500, 0.2); },
    fire: () => noise(0.35, 400, 0.35, 0.6, 'lowpass', 1800),
    boom: () => { noise(0.6, 300, 0.6, 0.5, 'lowpass', -150); tone(80, 0.5, 'sine', 0.4, -50); },
    jump: () => tone(300, 0.12, 'sine', 0.1, 200),
    grapple: () => { noise(0.25, 1200, 0.2, 2, 'bandpass', 2500); tone(500, 0.2, 'triangle', 0.1, 400); },
    glide: () => noise(0.4, 1500, 0.06, 0.5, 'bandpass'),
    level: () => [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => tone(f, 0.3, 'triangle', 0.2), i * 110)),
    craft: () => { tone(400, 0.1, 'square', 0.12); setTimeout(() => tone(600, 0.15, 'square', 0.12), 90); },
    die: () => tone(200, 1.2, 'sawtooth', 0.3, -150),
    slam: () => { tone(60, 0.6, 'sine', 0.6, -30); noise(0.5, 200, 0.5, 0.5, 'lowpass'); },
    heal: () => { tone(520, 0.3, 'sine', 0.2, 300); }
  };
  A.sfx = n => { if (S[n]) S[n](); };
  A.tick = dt => {
    if (!ctx) return;
    musicT -= dt;
    if (musicT <= 0) {
      musicT = 3 + Math.random() * 4;
      const sc = [261.6, 293.7, 329.6, 392, 440, 523.2];
      tone(sc[Math.floor(Math.random() * sc.length)] / 2, 4, 'sine', 0.045);
      if (Math.random() < 0.5) tone(sc[Math.floor(Math.random() * sc.length)], 3, 'triangle', 0.025);
    }
  };
  return A;
}
