// Chỉ số, túi đồ, chế tạo, cây kỹ năng, lưu game
const NAMES = {
  wood: 'Gỗ', stone: 'Đá', crystal: 'Tinh thể Shroud', hide: 'Da thú', meat: 'Thịt', core: 'Lõi Golem', potion: 'Bình hồi máu',
  axe: 'Rìu đá', wood_sword: 'Kiếm gỗ', stone_sword: 'Kiếm đá', crystal_blade: 'Kiếm tinh thể', golem_blade: 'Kiếm Golem',
  torch: 'Đuốc', lantern: 'Đèn lồng tinh thể', leather: 'Giáp da'
};
const RECIPES = [
  { id: 'axe', c: { wood: 3, stone: 3 }, d: 'Thu thập nhanh gấp đôi' },
  { id: 'wood_sword', c: { wood: 6 }, d: 'Sát thương 14' },
  { id: 'stone_sword', c: { wood: 3, stone: 8 }, d: 'Sát thương 22' },
  { id: 'crystal_blade', c: { wood: 4, stone: 4, crystal: 12 }, d: 'Sát thương 32' },
  { id: 'golem_blade', c: { core: 1, crystal: 10, stone: 6 }, d: 'Sát thương 46' },
  { id: 'torch', c: { wood: 2, crystal: 2 }, d: 'Giảm 60% sát thương từ Shroud' },
  { id: 'lantern', c: { crystal: 8, stone: 4 }, d: 'Giảm 92% sát thương từ Shroud' },
  { id: 'leather', c: { hide: 8 }, d: '-25% sát thương nhận, +20 máu' },
  { id: 'potion', c: { crystal: 2, meat: 1 }, d: 'Hồi 60 máu (dùng nút 🧪)', stack: true }
];
const WEAP = { wood_sword: 14, stone_sword: 22, crystal_blade: 32, golem_blade: 46 };
const SKILLS = [
  { id: 'dmg', n: 'Sức mạnh', d: '+12% sát thương mỗi cấp' },
  { id: 'hp', n: 'Thể lực', d: '+15 máu tối đa mỗi cấp' },
  { id: 'stam', n: 'Bền bỉ', d: '+12 thể lực tối đa mỗi cấp' },
  { id: 'mana', n: 'Ma lực', d: '+10 mana, +10% phép thuật mỗi cấp' }
];

export function createRPG(G) {
  const R = { names: NAMES };
  const D = { inv: {}, xp: 0, lvl: 1, sp: 0, sk: { dmg: 0, hp: 0, stam: 0, mana: 0 }, defeated: [], seed: null, pos: null };
  R.d = D;
  const have = k => (D.inv[k] || 0) > 0;

  R.stats = () => {
    let w = 8; for (const k in WEAP) if (have(k)) w = Math.max(w, WEAP[k]);
    return {
      maxHp: 100 + D.sk.hp * 15 + (have('leather') ? 20 : 0), maxSt: 100 + D.sk.stam * 12, maxMp: 60 + D.sk.mana * 10,
      dmgMul: 1 + D.sk.dmg * 0.12, spellMul: 1 + D.sk.mana * 0.1, weapon: w, gather: have('axe') ? 2 : 1,
      resist: have('lantern') ? 0.92 : have('torch') ? 0.6 : 0, armor: have('leather') ? 0.25 : 0
    };
  };
  R.give = (k, n = 1) => { D.inv[k] = (D.inv[k] || 0) + n; if (G.toast) G.toast('+' + n + ' ' + NAMES[k]); G.audio.sfx('pickup'); if (open) render(); };
  R.addXp = n => {
    D.xp += n;
    while (D.xp >= D.lvl * 60) {
      D.xp -= D.lvl * 60; D.lvl++; D.sp++;
      G.toast('Lên cấp ' + D.lvl + '! +1 điểm kỹ năng'); G.audio.sfx('level');
      if (G.player) { const s = R.stats(); G.player.hp = s.maxHp; G.player.st = s.maxSt; G.player.mp = s.maxMp; }
    }
    if (open) render();
  };
  R.deathPenalty = () => { for (const k of ['wood', 'stone', 'crystal']) if (D.inv[k]) D.inv[k] = Math.floor(D.inv[k] * 0.7); };
  R.usePotion = () => {
    const P = G.player;
    if (!have('potion')) { G.toast('Hết bình hồi máu (chế tạo trong 🎒)'); return; }
    if (P.hp >= R.stats().maxHp - 1) return;
    D.inv.potion--; P.heal(60); G.audio.sfx('heal'); if (open) render();
  };

  let open = false, tab = 'inv';
  const $ = G.$;
  R.toggle = () => { open = !open; $('panel').classList.toggle('hidden', !open); if (open) render(); };
  function canCraft(r) { return Object.keys(r.c).every(k => (D.inv[k] || 0) >= r.c[k]) && (r.stack || !have(r.id)); }
  function render() {
    document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    const el = $('pbody'); let h = '';
    if (tab === 'inv') {
      const s = R.stats();
      h += `<div class="item"><span>Cấp <b>${D.lvl}</b> · XP ${D.xp}/${D.lvl * 60}<small>Sát thương vũ khí ${s.weapon} · Giáp ${Math.round(s.armor * 100)}% · Kháng Shroud ${Math.round(s.resist * 100)}%</small></span></div>`;
      const ks = Object.keys(D.inv).filter(k => D.inv[k] > 0);
      h += ks.length ? ks.map(k => `<div class="item"><span>${NAMES[k]}</span><b>x${D.inv[k]}</b></div>`).join('') : '<div class="item">Túi đồ trống. Hãy đánh cây, đá và tinh thể!</div>';
    } else if (tab === 'craft') {
      h = RECIPES.map(r => `<div class="item"><span><b>${NAMES[r.id]}</b>${!r.stack && have(r.id) ? ' ✔' : ''}<small>${Object.keys(r.c).map(k => NAMES[k] + ' ' + (D.inv[k] || 0) + '/' + r.c[k]).join(' · ')}</small><small>${r.d}</small></span><button data-craft="${r.id}" ${canCraft(r) ? '' : 'disabled'}>Chế tạo</button></div>`).join('');
    } else if (tab === 'skill') {
      h = `<div class="item">Điểm kỹ năng: <b>${D.sp}</b></div>` + SKILLS.map(s => `<div class="item"><span><b>${s.n}</b> (cấp ${D.sk[s.id]})<small>${s.d}</small></span><button data-skill="${s.id}" ${D.sp > 0 ? '' : 'disabled'}>+</button></div>`).join('');
    }
    el.innerHTML = h;
  }
  $('panel').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.tab === 'close') return R.toggle();
    if (b.dataset.tab) { tab = b.dataset.tab; return render(); }
    if (b.dataset.craft) {
      const r = RECIPES.find(x => x.id === b.dataset.craft);
      if (!canCraft(r)) return;
      for (const k in r.c) D.inv[k] -= r.c[k];
      D.inv[r.id] = (D.inv[r.id] || 0) + 1; G.audio.sfx('craft'); G.toast('Đã chế tạo ' + NAMES[r.id]); R.save(); render();
    }
    if (b.dataset.skill && D.sp > 0) {
      D.sp--; D.sk[b.dataset.skill]++; G.audio.sfx('level');
      if (G.player) { const s = R.stats(); G.player.hp = Math.min(G.player.hp + 15, s.maxHp); }
      R.save(); render();
    }
  });

  R.save = () => {
    try {
      const out = Object.assign({}, D, { seed: G.world ? G.world.seed : D.seed });
      if (G.player && G.mode === 'single') out.pos = [G.player.pos.x, G.player.pos.y, G.player.pos.z];
      localStorage.setItem('shroud_save', JSON.stringify(out));
    } catch (e) { /* bỏ qua */ }
  };
  R.load = () => {
    try {
      const s = JSON.parse(localStorage.getItem('shroud_save') || 'null');
      if (s) { Object.assign(D, s); D.sk = Object.assign({ dmg: 0, hp: 0, stam: 0, mana: 0 }, s.sk); D.defeated = s.defeated || []; return true; }
    } catch (e) { /* bỏ qua */ }
    return false;
  };
  R.wipe = () => { try { localStorage.removeItem('shroud_save'); } catch (e) { /* bỏ qua */ } };
  return R;
}
