import * as THREE from 'three';

export function createCombat(G) {
  const V = THREE.Vector3;
  const K = { swingP: -1, cd: 0, spellCd: 0, pending: -1, shots: [] };

  // Hệ hạt (VFX) dùng chung
  const N = 240, ppos = new Float32Array(N * 3), pcol = new Float32Array(N * 3);
  const pvel = new Float32Array(N * 3), pbase = new Float32Array(N * 3), plife = new Float32Array(N), pmax = new Float32Array(N);
  for (let i = 0; i < N; i++) ppos[i * 3 + 1] = -999;
  const pg = new THREE.BufferGeometry();
  pg.setAttribute('position', new THREE.BufferAttribute(ppos, 3));
  pg.setAttribute('color', new THREE.BufferAttribute(pcol, 3));
  const points = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.55, vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  points.frustumCulled = false; G.scene.add(points);
  let pi = 0;
  const tc = new THREE.Color();
  K.burst = (p, color, n, speed, life) => {
    tc.set(color);
    for (let k = 0; k < n; k++) {
      const i = pi++ % N, a = Math.random() * 6.283, b = Math.random() * 2 - 0.4;
      ppos[i * 3] = p.x; ppos[i * 3 + 1] = p.y; ppos[i * 3 + 2] = p.z;
      pvel[i * 3] = Math.cos(a) * speed * Math.random(); pvel[i * 3 + 1] = b * speed * Math.random() + 1; pvel[i * 3 + 2] = Math.sin(a) * speed * Math.random();
      pbase[i * 3] = tc.r; pbase[i * 3 + 1] = tc.g; pbase[i * 3 + 2] = tc.b;
      plife[i] = pmax[i] = life * (0.6 + Math.random() * 0.6);
    }
  };

  // Hiệu ứng vệt chém
  const slash = new THREE.Mesh(new THREE.RingGeometry(1.0, 2.1, 20, 1, -0.95, 1.9).rotateX(-Math.PI / 2),
    new THREE.MeshBasicMaterial({ color: 0xbfe6ff, transparent: true, opacity: 0, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }));
  slash.visible = false; G.scene.add(slash);
  let slashT = 0;

  const aimDir = () => G.player.fwd();

  K.attack = () => {
    const P = G.player;
    if (K.cd > 0 || P.st < 8 || P.dead) return;
    P.st -= 8; K.cd = 0.45; K.swingP = 0; K.pending = 0.12;
    G.audio.sfx('slash');
    const f = aimDir();
    slash.position.set(P.pos.x + f.x * 1.2, P.pos.y + 1.2, P.pos.z + f.z * 1.2);
    slash.rotation.y = Math.atan2(-f.z, f.x); slash.visible = true; slashT = 0.28;
  };

  function strike() {
    const P = G.player, f = aimDir(), S = G.rpg.stats();
    let hitSomething = false;
    for (const e of G.enemies.list) {
      const dx = e.pos.x - P.pos.x, dz = e.pos.z - P.pos.z, d = Math.hypot(dx, dz);
      if (d > 3.4 + e.size || (dx * f.x + dz * f.z) / (d || 1) < 0.15) continue;
      const crit = Math.random() < 0.12;
      const dmg = S.weapon * S.dmgMul * (0.9 + Math.random() * 0.2) * (crit ? 1.8 : 1);
      G.enemies.hurt(e, dmg, f, crit); hitSomething = true;
    }
    // Thu thập tài nguyên phía trước (rìu tăng sức mạnh)
    let best = null;
    for (const r of G.world.nearResources(P.pos.x + f.x * 1.2, P.pos.z + f.z * 1.2, 2.2)) if (!best || r.dist < best.dist) best = r;
    if (best && !hitSomething) {
      G.audio.sfx(best.kind === 'tree' ? 'chop' : 'mine');
      K.burst(new V(best.x, best.y + 1, best.z), best.kind === 'crystal' ? 0xb07cff : best.kind === 'tree' ? 0x8a5a2a : 0xaaaaaa, 8, 3, 0.5);
      const drop = G.world.damageResource(best, S.gather);
      if (drop) for (const k in drop) G.rpg.give(k, drop[k]);
    }
    if (hitSomething) G.audio.sfx('hit');
  }

  K.cast = () => {
    const P = G.player;
    if (K.spellCd > 0 || P.mp < 25 || P.dead) return;
    P.mp -= 25; K.spellCd = 0.8; G.audio.sfx('fire');
    const f = aimDir(), o = new V(P.pos.x + f.x, P.pos.y + 1.4, P.pos.z + f.z);
    let d = P.view === 'fp' ? new V(f.x * Math.cos(P.fpPitch), Math.sin(P.fpPitch), f.z * Math.cos(P.fpPitch)) : new V(f.x, -0.02, f.z), bestC = 0.9;
    for (const e of G.enemies.list) {   // tự động ngắm mục tiêu gần hướng nhìn
      const t = new V(e.pos.x - o.x, e.pos.y + e.size - o.y, e.pos.z - o.z), L = t.length();
      if (L > 45) continue; t.divideScalar(L);
      const c = t.x * f.x + t.z * f.z; if (c > bestC - 0.0 && c > 0.9) { bestC = c; d = t; }
    }
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.38, 10, 8), new THREE.MeshBasicMaterial({ color: 0xff8a2a }));
    m.position.copy(o); G.scene.add(m);
    K.shots.push({ m, d: d.normalize(), life: 1.8 });
  };

  function explode(p) {
    G.audio.sfx('boom');
    K.burst(p, 0xff7a1a, 40, 9, 0.8); K.burst(p, 0xffdd66, 20, 5, 0.5);
    const S = G.rpg.stats();
    for (const e of G.enemies.list) {
      const d = Math.hypot(e.pos.x - p.x, e.pos.y + e.size - p.y, e.pos.z - p.z);
      if (d < 4.5 + e.size) G.enemies.hurt(e, 42 * S.spellMul * (0.9 + Math.random() * 0.2), new V(e.pos.x - p.x, 0, e.pos.z - p.z).normalize(), false);
    }
  }

  K.update = dt => {
    if (K.cd > 0) K.cd -= dt;
    if (K.spellCd > 0) K.spellCd -= dt;
    if (K.swingP >= 0) { K.swingP += dt / 0.3; if (K.swingP >= 1) K.swingP = -1; }
    if (K.pending >= 0) { K.pending -= dt; if (K.pending < 0) strike(); }
    if (slashT > 0) {
      slashT -= dt; const t = 1 - slashT / 0.28;
      slash.material.opacity = (1 - t) * 0.9; slash.scale.setScalar(1 + t * 0.5);
      if (slashT <= 0) slash.visible = false;
    }
    for (let i = K.shots.length - 1; i >= 0; i--) {
      const s = K.shots[i]; s.life -= dt;
      s.m.position.addScaledVector(s.d, 24 * dt);
      K.burst(s.m.position, 0xff6a10, 1, 1, 0.35);
      let hit = s.life <= 0 || s.m.position.y < G.world.heightAt(s.m.position.x, s.m.position.z);
      if (!hit) for (const e of G.enemies.list) {
        if (Math.hypot(e.pos.x - s.m.position.x, e.pos.y + e.size - s.m.position.y, e.pos.z - s.m.position.z) < 1.2 + e.size) { hit = true; break; }
      }
      if (hit) { explode(s.m.position.clone()); G.scene.remove(s.m); s.m.geometry.dispose(); s.m.material.dispose(); K.shots.splice(i, 1); }
    }
    for (let i = 0; i < N; i++) {
      if (plife[i] <= 0) continue;
      plife[i] -= dt;
      if (plife[i] <= 0) { ppos[i * 3 + 1] = -999; continue; }
      pvel[i * 3 + 1] -= 6 * dt;
      ppos[i * 3] += pvel[i * 3] * dt; ppos[i * 3 + 1] += pvel[i * 3 + 1] * dt; ppos[i * 3 + 2] += pvel[i * 3 + 2] * dt;
      const f = plife[i] / pmax[i];
      pcol[i * 3] = pbase[i * 3] * f; pcol[i * 3 + 1] = pbase[i * 3 + 1] * f; pcol[i * 3 + 2] = pbase[i * 3 + 2] * f;
    }
    pg.attributes.position.needsUpdate = true; pg.attributes.color.needsUpdate = true;
  };
  return K;
}
