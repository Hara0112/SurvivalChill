import * as THREE from 'three';

export function makeNoise(seed) {
  const perm = new Uint8Array(512);
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const p = [...Array(256).keys()];
  for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  const g = (i, j) => perm[(perm[i & 255] + j) & 255] / 255;
  const fade = t => t * t * (3 - 2 * t);
  return (x, y) => {
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const a = g(xi, yi), b = g(xi + 1, yi), c = g(xi, yi + 1), d = g(xi + 1, yi + 1);
    const u = fade(xf), v = fade(yf);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}
export function mulberry32(a) {
  return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export function createWorld(G, seed) {
  const n1 = makeNoise(seed), n2 = makeNoise((seed ^ 0x9e3779b9) >>> 0), n3 = makeNoise((seed + 7777) >>> 0);
  const fbm = (n, x, z, o = 4) => { let a = 1, f = 1, s = 0, t = 0; for (let i = 0; i < o; i++) { s += n(x * f, z * f) * a; t += a; a *= 0.5; f *= 2; } return s / t; };
  const CS = 48, SEG = 16, RAD = 3, WATER = -6;
  // Thành phố lớn: N x N khối (mỗi khối = 1 chunk), nền phẳng, đường phố 14m giữa các khối
  const CITY_N = 16, CITY_H = 4;
  const cAng = (seed % 6283) / 1000;
  const cIx = Math.round(Math.cos(cAng) * 560 / CS - CITY_N / 2), cIz = Math.round(Math.sin(cAng) * 560 / CS - CITY_N / 2);
  const city = { ix0: cIx, iz0: cIz, x0: cIx * CS, z0: cIz * CS, x1: (cIx + CITY_N) * CS, z1: (cIz + CITY_N) * CS };
  const W = { seed, CS, WATER, chunks: new Map(), group: new THREE.Group() };
  G.scene.add(W.group);

  W.cityDist = (x, z) => Math.hypot(Math.max(city.x0 - x, 0, x - city.x1), Math.max(city.z0 - z, 0, z - city.z1));
  W.inCity = (x, z) => W.cityDist(x, z) === 0;
  W.citySpawn = new THREE.Vector3((cIx + CITY_N / 2) * CS, CITY_H, (cIz + CITY_N / 2) * CS);   // ngã tư trung tâm
  W.heightAt = (x, z) => {
    const base = fbm(n1, x * 0.004, z * 0.004);
    const m = fbm(n3, x * 0.0022 + 50, z * 0.0022 + 50);
    let h = (base - 0.5) * 46 + Math.max(0, m - 0.5) * 150;
    const d = W.cityDist(x, z);
    if (d < 170) { let w = 1 - d / 170; w = w * w * (3 - 2 * w); h += (CITY_H - h) * w; }
    return h;
  };
  W.shroudAt = (x, z) => {
    const v = fbm(n2, x * 0.0045 + 200, z * 0.0045 - 90, 3);
    return Math.min(1, Math.max(0, (v - 0.56) * 5)) * Math.min(1, W.cityDist(x, z) / 200);
  };

  // Hình học & vật liệu dùng chung
  const trunkG = new THREE.CylinderGeometry(0.22, 0.32, 2.4, 5).translate(0, 1.2, 0);
  const crownG = new THREE.ConeGeometry(1.5, 3.6, 6).translate(0, 4.0, 0);
  const rockG = new THREE.DodecahedronGeometry(1, 0);
  const crysG = new THREE.OctahedronGeometry(0.7, 0).scale(1, 2, 1);
  const mTrunk = new THREE.MeshLambertMaterial({ color: 0x6b4a2b });
  const mCrown = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const mRock = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const mCrys = new THREE.MeshBasicMaterial({ color: 0xb07cff });
  const zeroM = new THREE.Matrix4().makeScale(0, 0, 0);
  const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3(), tmpE = new THREE.Euler();
  const colSand = new THREE.Color(0xd8c690), colGrass = new THREE.Color(0x4f8a3c), colHill = new THREE.Color(0x3e6a30),
    colRock = new THREE.Color(0x7d7a72), colSnow = new THREE.Color(0xf0f4f8), colShroud = new THREE.Color(0x3a1f4d), colAsph = new THREE.Color(0x4b4e57), tc = new THREE.Color();

  function terrainColor(h, s, out, cd) {
    if (h < -4.5) out.copy(colSand);
    else if (h < 3) out.copy(colSand).lerp(colGrass, Math.min(1, (h + 4.5) / 4));
    else if (h < 16) out.copy(colGrass).lerp(colHill, (h - 3) / 13);
    else if (h < 28) out.copy(colHill).lerp(colRock, (h - 16) / 12);
    else out.copy(colRock).lerp(colSnow, Math.min(1, (h - 28) / 10));
    out.lerp(colShroud, s * 0.8);
    if (cd < 25) out.lerp(colAsph, 1 - cd / 25);
  }

  function makeTex(emissive) {
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const g = cv.getContext('2d'), r = mulberry32(4242);
    g.fillStyle = emissive ? '#000' : '#d6d9df'; g.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) {
      const lit = r() < 0.3, x = i * 16 + 3, y = j * 16 + 4;
      if (emissive) { if (lit) { g.fillStyle = '#ffd27a'; g.fillRect(x, y, 10, 8); } }
      else { g.fillStyle = lit ? '#ffe3a0' : '#2f4058'; g.fillRect(x, y, 10, 8); }
    }
    const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; return t;
  }
  const cityMat = new THREE.MeshLambertMaterial({ vertexColors: true, map: makeTex(false), emissiveMap: makeTex(true), emissive: 0xffffff, emissiveIntensity: 0.05, side: THREE.DoubleSide });
  const roofMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
  W.cityMat = cityMat;
  const inCityChunk = (cx, cz) => cx >= city.ix0 && cx < city.ix0 + CITY_N && cz >= city.iz0 && cz < city.iz0 + CITY_N;

  // Một khối phố: 1 tòa tháp, 4 tòa nhỏ hoặc 2 tòa dài; trung tâm cao nhất
  function buildCity(cx, cz, rnd, grp) {
    const boxes = [], P = [], Nn = [], U = [], Cc = [], I = [], rP = [], rN = [], rC = [], rI = [];
    const col = new THREE.Color();
    const addBox = (x0, x1, z0, z1, y0, y1, c, uo, windows) => {
      const F = [[x0, z1, x1, z1, 0, 1, x0, x1], [x1, z0, x0, z0, 0, -1, x1, x0], [x1, z1, x1, z0, 1, 0, z1, z0], [x0, z0, x0, z1, -1, 0, z0, z1]];
      if (windows) for (const [ax, az, bx, bz, nx, nz, ua, ub] of F) {
        const b = P.length / 3;
        P.push(ax, y0, az, bx, y0, bz, bx, y1, bz, ax, y1, az);
        for (let k = 0; k < 4; k++) { Nn.push(nx, 0, nz); Cc.push(c.r, c.g, c.b); }
        U.push(ua / 32 + uo, y0 / 32, ub / 32 + uo, y0 / 32, ub / 32 + uo, y1 / 32, ua / 32 + uo, y1 / 32);
        I.push(b, b + 1, b + 2, b, b + 2, b + 3);
      }
      const b = rP.length / 3;
      rP.push(x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
      for (let k = 0; k < 4; k++) { rN.push(0, 1, 0); rC.push(c.r * 0.55, c.g * 0.55, c.b * 0.55); }
      rI.push(b, b + 1, b + 2, b, b + 2, b + 3);
    };
    const mk = (x0, x1, z0, z1, h) => {
      const hh = Math.max(12, Math.round(h / 4) * 4), y0 = CITY_H, y1 = CITY_H + hh, uo = rnd();
      col.setHSL(0.55 + rnd() * 0.1, 0.05 + rnd() * 0.14, 0.62 + rnd() * 0.28);
      addBox(x0, x1, z0, z1, y0, y1, col, uo, true); boxes.push({ x0, x1, z0, z1, y1 });
      if (hh >= 60) {
        const t = y1 + Math.round(hh * 0.3 / 4) * 4;
        addBox(x0 + 5, x1 - 5, z0 + 5, z1 - 5, y1, t, col, uo, true); boxes.push({ x0: x0 + 5, x1: x1 - 5, z0: z0 + 5, z1: z1 - 5, y1: t });
        if (hh >= 100) { const mx = (x0 + x1) / 2, mz = (z0 + z1) / 2; addBox(mx - 0.4, mx + 0.4, mz - 0.4, mz + 0.4, t, t + 16, col, uo, true); }
      }
    };
    const m = 7, ax0 = cx * CS + m, ax1 = cx * CS + CS - m, az0 = cz * CS + m, az1 = cz * CS + CS - m;
    const ccx = city.ix0 + CITY_N / 2, ccz = city.iz0 + CITY_N / 2;
    const core = Math.max(0, 1 - Math.hypot((cx + 0.5 - ccx) / (CITY_N / 2), (cz + 0.5 - ccz) / (CITY_N / 2)));
    const H = () => (14 + rnd() * 40) * (1 + core * 2.4);
    const t = rnd();
    if (t < 0.2) mk(ax0 + 2, ax1 - 2, az0 + 2, az1 - 2, H() * 1.15);
    else if (t < 0.62) { const g = 4, w = (34 - g) / 2; for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) mk(ax0 + i * (w + g), ax0 + i * (w + g) + w, az0 + j * (w + g), az0 + j * (w + g) + w, H()); }
    else if (rnd() < 0.5) { mk(ax0, ax0 + 15, az0, az1, H()); mk(ax1 - 15, ax1, az0, az1, H()); }
    else { mk(ax0, ax1, az0, az0 + 15, H()); mk(ax0, ax1, az1 - 15, az1, H()); }
    const mkMesh = (pos, nor, uv, colr, idx, mat) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
      if (uv) g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      g.setAttribute('color', new THREE.Float32BufferAttribute(colr, 3)); g.setIndex(idx);
      const me = new THREE.Mesh(g, mat); me.castShadow = me.receiveShadow = true; me.userData.city = true; grp.add(me);
    };
    mkMesh(P, Nn, U, Cc, I, cityMat);
    mkMesh(rP, rN, null, rC, rI, roofMat);
    return boxes;
  }

  function build(cx, cz) {
    const grp = new THREE.Group();
    const g = new THREE.PlaneGeometry(CS, CS, SEG, SEG);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position, cols = new Float32Array(pos.count * 3);
    const ox = cx * CS + CS / 2, oz = cz * CS + CS / 2;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) + ox, z = pos.getZ(i) + oz, h = W.heightAt(x, z);
      pos.setY(i, h);
      terrainColor(h, W.shroudAt(x, z), tc, W.cityDist(x, z));
      cols[i * 3] = tc.r; cols[i * 3 + 1] = tc.g; cols[i * 3 + 2] = tc.b;
    }
    g.translate(ox, 0, oz);
    g.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    const terrain = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
    terrain.receiveShadow = true;
    grp.add(terrain);

    // Tài nguyên (cây, đá, tinh thể Shroud) - sinh theo seed nên mọi người chơi thấy giống nhau
    const rnd = mulberry32((((cx * 73856093) ^ (cz * 19349663) ^ seed) >>> 0));
    if (inCityChunk(cx, cz)) { const boxes = buildCity(cx, cz, rnd, grp); W.group.add(grp); return { grp, res: [], terrain, boxes }; }
    const trees = [], rocks = [], crys = [], res = [];
    for (let i = 0; i < 18; i++) {
      const x = cx * CS + rnd() * CS, z = cz * CS + rnd() * CS, h = W.heightAt(x, z), s = W.shroudAt(x, z), r = rnd(), sc = 0.8 + rnd() * 0.8, rot = rnd() * 6.28, v = rnd();
      if (h < -3 || h > 26) continue;
      if (r < 0.68) trees.push({ x, y: h, z, sc, rot, s, v }); else rocks.push({ x, y: h, z, sc, rot, v });
    }
    for (let i = 0; i < 5; i++) {
      const x = cx * CS + rnd() * CS, z = cz * CS + rnd() * CS, h = W.heightAt(x, z), s = W.shroudAt(x, z), sc = 0.9 + rnd() * 0.8, rot = rnd() * 6.28;
      if (s > 0.35 && h > -3) crys.push({ x, y: h, z, sc, rot });
    }
    const mk = (geo, mat, list, shadow) => {
      if (!list.length) return null;
      const m = new THREE.InstancedMesh(geo, mat, list.length);
      m.castShadow = shadow; grp.add(m); return m;
    };
    const setM = (m, i, o, sy) => {
      tmpE.set(0, o.rot, 0); tmpQ.setFromEuler(tmpE);
      tmpS.set(o.sc, o.sc * (sy || 1), o.sc); tmpP.set(o.x, o.y, o.z);
      tmpM.compose(tmpP, tmpQ, tmpS); m.setMatrixAt(i, tmpM);
    };
    const tT = mk(trunkG, mTrunk, trees, true), tC = mk(crownG, mCrown, trees, true), rM = mk(rockG, mRock, rocks, true), cM = mk(crysG, mCrys, crys, false);
    trees.forEach((o, i) => {
      setM(tT, i, o); setM(tC, i, o);
      tc.set(0x2f7a35).offsetHSL((o.v - 0.5) * 0.05, 0, (o.v - 0.5) * 0.1).lerp(colShroud.clone().offsetHSL(0, 0.1, 0.12), o.s);
      tC.setColorAt(i, tc);
      res.push({ kind: 'tree', x: o.x, y: o.y, z: o.z, r: 0.7 * o.sc, hp: 3, parts: [[tT, i], [tC, i]], alive: true });
    });
    rocks.forEach((o, i) => {
      o.y += 0.2; setM(rM, i, o, 0.7);
      tc.set(0x8a8a8a).offsetHSL(0, 0, (o.v - 0.5) * 0.15); rM.setColorAt(i, tc);
      res.push({ kind: 'rock', x: o.x, y: o.y, z: o.z, r: 0.9 * o.sc, hp: 4, parts: [[rM, i]], alive: true });
    });
    crys.forEach((o, i) => {
      o.y += 1; setM(cM, i, o);
      res.push({ kind: 'crystal', x: o.x, y: o.y, z: o.z, r: 0.7 * o.sc, hp: 3, parts: [[cM, i]], alive: true });
    });
    [tT, tC, rM, cM].forEach(m => { if (m) { m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; } });
    W.group.add(grp);
    return { grp, res, terrain, boxes: [] };
  }

  function unload(key) {
    const c = W.chunks.get(key);
    c.terrain.geometry.dispose(); c.terrain.material.dispose();
    c.grp.traverse(o => { if (o.isInstancedMesh) o.dispose(); else if (o.isMesh && o.userData.city) o.geometry.dispose(); });
    W.group.remove(c.grp); W.chunks.delete(key);
  }

  W.update = (px, pz) => {
    const ccx = Math.floor(px / CS), ccz = Math.floor(pz / CS);
    let built = 0;
    const RR = W.cityDist(px, pz) < 90 ? 4 : RAD;
    for (let r = 0; r <= RR && built < 1; r++) {
      for (let dx = -r; dx <= r && built < 1; dx++) for (let dz = -r; dz <= r && built < 1; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const key = (ccx + dx) + ',' + (ccz + dz);
        if (!W.chunks.has(key)) { W.chunks.set(key, build(ccx + dx, ccz + dz)); built++; }
      }
    }
    for (const key of [...W.chunks.keys()]) {
      const [x, z] = key.split(',').map(Number);
      if (Math.max(Math.abs(x - ccx), Math.abs(z - ccz)) > 5) unload(key);
    }
    water.position.set(px, WATER, pz);
  };
  W.preload = (px, pz) => {
    const ccx = Math.floor(px / CS), ccz = Math.floor(pz / CS);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const key = (ccx + dx) + ',' + (ccz + dz);
      if (!W.chunks.has(key)) W.chunks.set(key, build(ccx + dx, ccz + dz));
    }
  };

  const boxesAt = (x, z) => { const c = W.chunks.get(Math.floor(x / CS) + ',' + Math.floor(z / CS)); return c ? c.boxes : []; };
  W.boxAt = (x, z) => { let best = null; for (const b of boxesAt(x, z)) if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && (!best || b.y1 > best.y1)) best = b; return best; };
  // Độ cao bề mặt đứng được (mái nhà nếu đang ở phía trên mái)
  W.surfaceAt = (x, z, y) => { let h = W.heightAt(x, z); for (const b of boxesAt(x, z)) if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && y >= b.y1 - 0.8 && b.y1 > h) h = b.y1; return h; };
  W.blocked = (x, z, y) => { for (const b of boxesAt(x, z)) if (x > b.x0 - 0.4 && x < b.x1 + 0.4 && z > b.z0 - 0.4 && z < b.z1 + 0.4 && y < b.y1 - 0.6) return true; return false; };
  W.solidAt = (x, y, z) => { if (y < W.heightAt(x, z) + 0.3) return true; const b = W.boxAt(x, z); return !!(b && y < b.y1); };

  W.nearResources = (x, z, range) => {
    const out = [], ccx = Math.floor(x / CS), ccz = Math.floor(z / CS);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const c = W.chunks.get((ccx + dx) + ',' + (ccz + dz));
      if (!c) continue;
      for (const r of c.res) {
        if (!r.alive) continue;
        const d = Math.hypot(r.x - x, r.z - z);
        if (d < range + r.r) { r.dist = d; out.push(r); }
      }
    }
    return out;
  };
  // Trả về phần thưởng nếu tài nguyên bị phá hủy
  W.damageResource = (r, dmg) => {
    r.hp -= dmg;
    if (r.hp > 0) return null;
    r.alive = false;
    const touched = new Set();
    r.parts.forEach(([m, i]) => { m.setMatrixAt(i, zeroM); touched.add(m); });
    touched.forEach(m => { m.instanceMatrix.needsUpdate = true; });
    if (r.kind === 'tree') return { wood: 3 + Math.floor(Math.random() * 3) };
    if (r.kind === 'rock') return { stone: 2 + Math.floor(Math.random() * 3) };
    return { crystal: 1 + Math.floor(Math.random() * 2) };
  };

  const water = new THREE.Mesh(new THREE.PlaneGeometry(900, 900).rotateX(-Math.PI / 2),
    new THREE.MeshLambertMaterial({ color: 0x2a6fa8, transparent: true, opacity: 0.8 }));
  G.scene.add(water);
  return W;
}
