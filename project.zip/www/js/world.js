import * as THREE from 'three';

export function makeNoise(seed) {
  const perm = new Uint8Array(512);
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const p = [...Array(256).keys()];
  for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  const g = (i, j) => perm[(perm[i & 255] + j) & 255] / 255;
  const fade = t => t * t * (3 - 2 * t);
  return (x, y) => {
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const a = g(xi, yi), b = g(xi + 1, yi), c = g(xi, yi + 1), d = g(xi + 1, yi + 1);
    const u = fade(xf), v = fade(yf);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}
export function mulberry32(a) {
  return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export function createWorld(G, seed) {
  const n1 = makeNoise(seed), n2 = makeNoise((seed ^ 0x9e3779b9) >>> 0), n3 = makeNoise((seed + 7777) >>> 0);
  const fbm = (n, x, z, o = 4) => { let a = 1, f = 1, s = 0, t = 0; for (let i = 0; i < o; i++) { s += n(x * f, z * f) * a; t += a; a *= 0.5; f *= 2; } return s / t; };
  const CS = 48, SEG = 16, RAD = 3, WATER = -6;
  const W = { seed, CS, WATER, chunks: new Map(), group: new THREE.Group() };
  G.scene.add(W.group);

  W.heightAt = (x, z) => {
    const base = fbm(n1, x * 0.004, z * 0.004);
    const m = fbm(n3, x * 0.0022 + 50, z * 0.0022 + 50);
    return (base - 0.5) * 46 + Math.max(0, m - 0.5) * 150;
  };
  W.shroudAt = (x, z) => {
    const v = fbm(n2, x * 0.0045 + 200, z * 0.0045 - 90, 3);
    return Math.min(1, Math.max(0, (v - 0.56) * 5));
  };

  // Hình học & vật liệu dùng chung
  const trunkG = new THREE.CylinderGeometry(0.22, 0.32, 2.4, 5).translate(0, 1.2, 0);
  const crownG = new THREE.ConeGeometry(1.5, 3.6, 6).translate(0, 4.0, 0);
  const rockG = new THREE.DodecahedronGeometry(1, 0);
  const crysG = new THREE.OctahedronGeometry(0.7, 0).scale(1, 2, 1);
  const mTrunk = new THREE.MeshLambertMaterial({ color: 0x6b4a2b });
  const mCrown = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const mRock = new THREE.MeshLambertMaterial({ color: 0xffffff });
  const mCrys = new THREE.MeshBasicMaterial({ color: 0xb07cff });
  const zeroM = new THREE.Matrix4().makeScale(0, 0, 0);
  const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3(), tmpE = new THREE.Euler();
  const colSand = new THREE.Color(0xd8c690), colGrass = new THREE.Color(0x4f8a3c), colHill = new THREE.Color(0x3e6a30),
    colRock = new THREE.Color(0x7d7a72), colSnow = new THREE.Color(0xf0f4f8), colShroud = new THREE.Color(0x3a1f4d), tc = new THREE.Color();

  function terrainColor(h, s, out) {
    if (h < -4.5) out.copy(colSand);
    else if (h < 3) out.copy(colSand).lerp(colGrass, Math.min(1, (h + 4.5) / 4));
    else if (h < 16) out.copy(colGrass).lerp(colHill, (h - 3) / 13);
    else if (h < 28) out.copy(colHill).lerp(colRock, (h - 16) / 12);
    else out.copy(colRock).lerp(colSnow, Math.min(1, (h - 28) / 10));
    out.lerp(colShroud, s * 0.8);
  }

  function build(cx, cz) {
    const grp = new THREE.Group();
    const g = new THREE.PlaneGeometry(CS, CS, SEG, SEG);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position, cols = new Float32Array(pos.count * 3);
    const ox = cx * CS + CS / 2, oz = cz * CS + CS / 2;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) + ox, z = pos.getZ(i) + oz, h = W.heightAt(x, z);
      pos.setY(i, h);
      terrainColor(h, W.shroudAt(x, z), tc);
      cols[i * 3] = tc.r; cols[i * 3 + 1] = tc.g; cols[i * 3 + 2] = tc.b;
    }
    g.translate(ox, 0, oz);
    g.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    const terrain = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
    terrain.receiveShadow = true;
    grp.add(terrain);

    // Tài nguyên (cây, đá, tinh thể Shroud) - sinh theo seed nên mọi người chơi thấy giống nhau
    const rnd = mulberry32((((cx * 73856093) ^ (cz * 19349663) ^ seed) >>> 0));
    const trees = [], rocks = [], crys = [], res = [];
    for (let i = 0; i < 18; i++) {
      const x = cx * CS + rnd() * CS, z = cz * CS + rnd() * CS, h = W.heightAt(x, z), s = W.shroudAt(x, z), r = rnd(), sc = 0.8 + rnd() * 0.8, rot = rnd() * 6.28, v = rnd();
      if (h < -3 || h > 26) continue;
      if (r < 0.68) trees.push({ x, y: h, z, sc, rot, s, v }); else rocks.push({ x, y: h, z, sc, rot, v });
    }
    for (let i = 0; i < 5; i++) {
      const x = cx * CS + rnd() * CS, z = cz * CS + rnd() * CS, h = W.heightAt(x, z), s = W.shroudAt(x, z), sc = 0.9 + rnd() * 0.8, rot = rnd() * 6.28;
      if (s > 0.35 && h > -3) crys.push({ x, y: h, z, sc, rot });
    }
    const mk = (geo, mat, list, shadow) => {
      if (!list.length) return null;
      const m = new THREE.InstancedMesh(geo, mat, list.length);
      m.castShadow = shadow; grp.add(m); return m;
    };
    const setM = (m, i, o, sy) => {
      tmpE.set(0, o.rot, 0); tmpQ.setFromEuler(tmpE);
      tmpS.set(o.sc, o.sc * (sy || 1), o.sc); tmpP.set(o.x, o.y, o.z);
      tmpM.compose(tmpP, tmpQ, tmpS); m.setMatrixAt(i, tmpM);
    };
    const tT = mk(trunkG, mTrunk, trees, true), tC = mk(crownG, mCrown, trees, true), rM = mk(rockG, mRock, rocks, true), cM = mk(crysG, mCrys, crys, false);
    trees.forEach((o, i) => {
      setM(tT, i, o); setM(tC, i, o);
      tc.set(0x2f7a35).offsetHSL((o.v - 0.5) * 0.05, 0, (o.v - 0.5) * 0.1).lerp(colShroud.clone().offsetHSL(0, 0.1, 0.12), o.s);
      tC.setColorAt(i, tc);
      res.push({ kind: 'tree', x: o.x, y: o.y, z: o.z, r: 0.7 * o.sc, hp: 3, parts: [[tT, i], [tC, i]], alive: true });
    });
    rocks.forEach((o, i) => {
      o.y += 0.2; setM(rM, i, o, 0.7);
      tc.set(0x8a8a8a).offsetHSL(0, 0, (o.v - 0.5) * 0.15); rM.setColorAt(i, tc);
      res.push({ kind: 'rock', x: o.x, y: o.y, z: o.z, r: 0.9 * o.sc, hp: 4, parts: [[rM, i]], alive: true });
    });
    crys.forEach((o, i) => {
      o.y += 1; setM(cM, i, o);
      res.push({ kind: 'crystal', x: o.x, y: o.y, z: o.z, r: 0.7 * o.sc, hp: 3, parts: [[cM, i]], alive: true });
    });
    [tT, tC, rM, cM].forEach(m => { if (m) { m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; } });
    W.group.add(grp);
    return { grp, res, terrain };
  }

  function unload(key) {
    const c = W.chunks.get(key);
    c.terrain.geometry.dispose(); c.terrain.material.dispose();
    c.grp.traverse(o => { if (o.isInstancedMesh) o.dispose(); });
    W.group.remove(c.grp); W.chunks.delete(key);
  }

  W.update = (px, pz) => {
    const ccx = Math.floor(px / CS), ccz = Math.floor(pz / CS);
    let built = 0;
    for (let r = 0; r <= RAD && built < 1; r++) {
      for (let dx = -r; dx <= r && built < 1; dx++) for (let dz = -r; dz <= r && built < 1; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const key = (ccx + dx) + ',' + (ccz + dz);
        if (!W.chunks.has(key)) { W.chunks.set(key, build(ccx + dx, ccz + dz)); built++; }
      }
    }
    for (const key of [...W.chunks.keys()]) {
      const [x, z] = key.split(',').map(Number);
      if (Math.max(Math.abs(x - ccx), Math.abs(z - ccz)) > RAD + 1) unload(key);
    }
    water.position.set(px, WATER, pz);
  };
  W.preload = (px, pz) => {
    const ccx = Math.floor(px / CS), ccz = Math.floor(pz / CS);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const key = (ccx + dx) + ',' + (ccz + dz);
      if (!W.chunks.has(key)) W.chunks.set(key, build(ccx + dx, ccz + dz));
    }
  };

  W.nearResources = (x, z, range) => {
    const out = [], ccx = Math.floor(x / CS), ccz = Math.floor(z / CS);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const c = W.chunks.get((ccx + dx) + ',' + (ccz + dz));
      if (!c) continue;
      for (const r of c.res) {
        if (!r.alive) continue;
        const d = Math.hypot(r.x - x, r.z - z);
        if (d < range + r.r) { r.dist = d; out.push(r); }
      }
    }
    return out;
  };
  // Trả về phần thưởng nếu tài nguyên bị phá hủy
  W.damageResource = (r, dmg) => {
    r.hp -= dmg;
    if (r.hp > 0) return null;
    r.alive = false;
    const touched = new Set();
    r.parts.forEach(([m, i]) => { m.setMatrixAt(i, zeroM); touched.add(m); });
    touched.forEach(m => { m.instanceMatrix.needsUpdate = true; });
    if (r.kind === 'tree') return { wood: 3 + Math.floor(Math.random() * 3) };
    if (r.kind === 'rock') return { stone: 2 + Math.floor(Math.random() * 3) };
    return { crystal: 1 + Math.floor(Math.random() * 2) };
  };

  const water = new THREE.Mesh(new THREE.PlaneGeometry(900, 900).rotateX(-Math.PI / 2),
    new THREE.MeshLambertMaterial({ color: 0x2a6fa8, transparent: true, opacity: 0.8 }));
  G.scene.add(water);
  return W;
}
