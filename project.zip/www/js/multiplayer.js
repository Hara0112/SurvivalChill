// 1–8 người chơi P2P qua WebRTC (PeerJS, dùng máy chủ báo hiệu công cộng, không cần backend riêng).
// Chủ phòng là trung tâm chuyển tiếp trạng thái. Thế giới giống nhau nhờ cùng seed.
import * as THREE from 'three';
import { makeCharacter, animateCharacter } from './player.js';

export function createMultiplayer(G) {
  const M = { active: false, isHost: false, peer: null, conns: [], remote: new Map(), code: '', myId: 'host', seed: 0 };
  const COLORS = [0xb5483d, 0x3db57a, 0xb59a3d, 0x8a3db5, 0x3db5b0, 0xb53d8a, 0x777777];
  let timer = 0;
  const label = id => 'P' + String(id).slice(-3).toUpperCase();

  M.host = seed => new Promise((res, rej) => {
    if (typeof Peer === 'undefined') return rej(new Error('Không tải được PeerJS (cần Internet)'));
    const code = Math.random().toString(36).slice(2, 7).toUpperCase();
    const peer = new Peer('shroudrealms-' + code);
    peer.on('open', () => { Object.assign(M, { peer, isHost: true, active: true, code, seed, myId: 'host' }); res(code); });
    peer.on('error', e => rej(new Error('Lỗi mạng: ' + e.type)));
    peer.on('connection', c => {
      if (M.conns.length >= 7) { c.on('open', () => { c.send({ t: 'full' }); setTimeout(() => c.close(), 400); }); return; }
      c.on('open', () => { M.conns.push(c); c.send({ t: 'hello', seed, id: c.peer }); if (G.toast) G.toast('Có người chơi mới vào phòng'); });
      c.on('data', d => onData(d, c));
      c.on('close', () => drop(c)); c.on('error', () => drop(c));
    });
  });

  M.join = code => new Promise((res, rej) => {
    if (typeof Peer === 'undefined') return rej(new Error('Không tải được PeerJS (cần Internet)'));
    const peer = new Peer();
    const to = setTimeout(() => rej(new Error('Hết thời gian chờ, kiểm tra mã phòng')), 15000);
    peer.on('open', id => {
      M.myId = id;
      const c = peer.connect('shroudrealms-' + code.toUpperCase().trim());
      c.on('data', d => {
        if (d.t === 'hello') { clearTimeout(to); Object.assign(M, { peer, conns: [c], active: true, isHost: false, code }); res(d.seed); }
        else if (d.t === 'full') { clearTimeout(to); rej(new Error('Phòng đã đầy (tối đa 8 người)')); }
        else onData(d, c);
      });
      c.on('close', () => { if (G.toast) G.toast('Mất kết nối với chủ phòng'); M.active = false; });
    });
    peer.on('error', e => { clearTimeout(to); rej(new Error(e.type === 'peer-unavailable' ? 'Không tìm thấy phòng' : 'Lỗi mạng: ' + e.type)); });
  });

  function drop(c) {
    M.conns = M.conns.filter(x => x !== c);
    if (c.pid) { removeRemote(c.pid); M.conns.forEach(o => o.open && o.send({ t: 'leave', id: c.pid })); }
  }
  function removeRemote(id) {
    const r = M.remote.get(id); if (!r) return;
    G.scene.remove(r.g); r.g.traverse(o => { if (o.isMesh || o.isSprite) { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } } });
    M.remote.delete(id);
  }
  function nameSprite(txt) {
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 32;
    const x = cv.getContext('2d'); x.font = 'bold 22px sans-serif'; x.fillStyle = '#fff'; x.textAlign = 'center'; x.strokeStyle = '#000'; x.lineWidth = 4;
    x.strokeText(txt, 64, 24); x.fillText(txt, 64, 24);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), depthTest: false }));
    s.scale.set(2, 0.5, 1); s.position.y = 2.6; return s;
  }
  function onData(d, c) {
    if (d.t === 's') {
      if (!G.started || d.id === M.myId) return;
      c.pid = c.pid || d.id;
      let r = M.remote.get(d.id);
      if (!r) {
        const g = makeCharacter(COLORS[M.remote.size % COLORS.length]); g.add(nameSprite(label(d.id))); G.scene.add(g);
        r = { g, tp: new THREE.Vector3(d.x, d.y, d.z), tr: d.r, v: 0, a: 0, last: 0 }; g.position.copy(r.tp); M.remote.set(d.id, r);
        if (G.toast) G.toast(label(d.id) + ' đã tham gia');
      }
      r.tp.set(d.x, d.y, d.z); r.tr = d.r; r.v = d.v; r.sw = d.w; r.last = performance.now();
      if (M.isHost) M.conns.forEach(o => { if (o !== c && o.open) o.send(d); });
    } else if (d.t === 'leave') removeRemote(d.id);
  }

  M.update = dt => {
    if (!M.active) return;
    const P = G.player; timer += dt;
    if (timer >= 0.1) {
      timer = 0;
      const msg = { t: 's', id: M.myId, x: +P.pos.x.toFixed(2), y: +P.pos.y.toFixed(2), z: +P.pos.z.toFixed(2), r: +P.face.toFixed(2), v: +P.speedH.toFixed(1), w: G.combat.swingP };
      M.conns.forEach(c => { if (c.open) c.send(msg); });
    }
    const now = performance.now();
    for (const [id, r] of [...M.remote]) {
      if (now - r.last > 6000) { removeRemote(id); continue; }
      r.g.position.lerp(r.tp, Math.min(1, dt * 10));
      let da = r.tr - r.g.rotation.y; while (da > Math.PI) da -= 6.283; while (da < -Math.PI) da += 6.283;
      r.g.rotation.y += da * Math.min(1, dt * 10);
      r.a += dt * (4 + r.v * 1.1);
      animateCharacter(r.g, r.a, r.v, r.sw === undefined ? -1 : r.sw, false);
    }
  };
  M.count = () => 1 + M.remote.size;
  return M;
}
