import * as THREE from 'three';

const mesh = (g, c) => new THREE.Mesh(g, new THREE.MeshLambertMaterial({ color: c }));
const box = (w, h, d, c) => mesh(new THREE.BoxGeometry(w, h, d), c);

// Nhân vật tạo bằng code (dùng cho cả người chơi và người chơi từ xa)
export function makeCharacter(color = 0x3d6fb5) {
  const g = new THREE.Group();
  const body = box(0.7, 0.9, 0.4, color); body.position.y = 1.15; g.add(body);
  const head = mesh(new THREE.SphereGeometry(0.26, 10, 8), 0xe8b98a); head.position.y = 1.85; g.add(head);
  const hair = mesh(new THREE.SphereGeometry(0.28, 8, 6, 0, 6.283, 0, 1.6), 0x3a2a1a); hair.position.y = 1.9; g.add(hair);
  const limb = (x, y, w, h, c) => { const p = new THREE.Group(); p.position.set(x, y, 0); const m = box(w, h, w, c); m.position.y = -h / 2; p.add(m); g.add(p); return p; };
  const legL = limb(-0.18, 0.72, 0.26, 0.72, 0x38384a), legR = limb(0.18, 0.72, 0.26, 0.72, 0x38384a);
  const armL = limb(-0.47, 1.55, 0.2, 0.7, color), armR = limb(0.47, 1.55, 0.2, 0.7, color);
  const sword = new THREE.Group();
  const blade = box(0.07, 0.05, 1.1, 0xd5dde6); blade.position.set(0, -0.65, 0.55);
  const hilt = box(0.3, 0.06, 0.08, 0x7a5a2a); hilt.position.set(0, -0.65, 0.05);
  sword.add(blade, hilt); armR.add(sword);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  g.userData = { legL, legR, armL, armR, sword };
  return g;
}
export function animateCharacter(model, t, speed, swingP, gliding) {
  const u = model.userData, a = Math.sin(t) * Math.min(1, speed / 5) * 0.9;
  u.legL.rotation.x = a; u.legR.rotation.x = -a;
  if (gliding) { u.armL.rotation.x = u.armR.rotation.x = -2.9; u.legL.rotation.x = u.legR.rotation.x = 0.2; return; }
  u.armL.rotation.x = -a;
  u.armR.rotation.x = swingP >= 0 ? -2.6 + swingP * 2.1 : a - 0.5;
}

export function createPlayer(G) {
  const V = THREE.Vector3, C = G.ctl;
  const P = { pos: new V(), vel: new V(), yaw: 0, pitch: 0.35, fpPitch: 0, dist: 6.5, face: 0, grounded: true, gliding: false, grap: null, grapCd: 0, anim: 0, dead: false, invuln: 0, speedH: 0, baseFov: 78 };
  const model = makeCharacter(); G.scene.add(model); P.model = model;
  const wing = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.05, 1.5), new THREE.MeshLambertMaterial({ color: 0xc23b3b, side: THREE.DoubleSide }));
  wing.position.y = 2.5; wing.visible = false; model.add(wing);
  // Sợi tơ
  const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V(), new V()]), new THREE.LineBasicMaterial({ color: 0xffffff }));
  line.frustumCulled = false; line.visible = false; G.scene.add(line);

  // Góc nhìn thứ nhất: tay + kiếm gắn vào camera
  G.scene.add(G.camera);
  const vm = new THREE.Group();
  const vArm = box(0.13, 0.13, 0.55, 0xe8b98a); vArm.position.set(0, 0, -0.15);
  const vBlade = box(0.05, 0.035, 0.95, 0xd5dde6); vBlade.position.set(0, 0.03, -0.85);
  const vGuard = box(0.22, 0.05, 0.05, 0x7a5a2a); vGuard.position.set(0, 0.03, -0.42);
  vm.add(vArm, vBlade, vGuard); vm.position.set(0.34, -0.32, -0.5); vm.rotation.x = 0.3;
  G.camera.add(vm);
  try { P.view = localStorage.getItem('shroud_view') || 'fp'; } catch (e) { P.view = 'fp'; }
  P.setView = (v, quiet) => {
    P.view = v; try { localStorage.setItem('shroud_view', v); } catch (e) { /* bỏ qua */ }
    P.baseFov = v === 'fp' ? 78 : 65; G.camera.fov = P.baseFov; G.camera.updateProjectionMatrix();
    G.$('cross').classList.toggle('hidden', v !== 'fp');
    if (!quiet) G.toast(v === 'fp' ? 'Góc nhìn thứ nhất' : 'Góc nhìn thứ ba');
  };
  P.setView(P.view, true);

  P.fwd = () => new V(-Math.sin(P.yaw), 0, -Math.cos(P.yaw));
  P.spawnPos = G.world.citySpawn.clone();     // ngã tư trung tâm thành phố
  P.pos.copy(P.spawnPos);
  const s0 = G.rpg.stats(); P.hp = s0.maxHp; P.st = s0.maxSt; P.mp = s0.maxMp;

  P.heal = n => { P.hp = Math.min(G.rpg.stats().maxHp, P.hp + n); };
  P.dot = d => { if (!P.dead) { P.hp -= d; if (P.hp <= 0) die(); } };
  P.hurt = d => {
    if (P.dead || P.invuln > 0) return;
    P.invuln = 0.35; P.hp -= d * (1 - G.rpg.stats().armor);
    G.audio.sfx('hurt'); const h = G.$('hurt'); h.style.opacity = 0.9; setTimeout(() => h.style.opacity = 0, 120);
    if (P.hp <= 0) die();
  };
  function die() {
    P.dead = true; P.grap = null; G.audio.sfx('die'); G.toast('Bạn đã gục ngã... hồi sinh sau 3 giây');
    G.rpg.deathPenalty();
    setTimeout(() => {
      const s = G.rpg.stats(); P.pos.copy(P.spawnPos); P.vel.set(0, 0, 0);
      P.hp = s.maxHp; P.st = s.maxSt; P.mp = s.maxMp; P.dead = false; P.grap = null;
    }, 3000);
  }

  // ---- ĐU TƠ (kiểu Spider-Man): giữ nút để đu, thả nút để bay ----
  function startSwing() {
    const W = G.world, f = P.fwd();
    const base = P.view === 'fp' ? P.fpPitch + 0.35 : 0.7 - P.pitch;
    const o = new V(P.pos.x, P.pos.y + 1.4, P.pos.z), p = new V(), d = new V();
    for (const de of [0, 0.15, 0.3, 0.5, 0.7, -0.15, -0.3]) {   // thử nhiều góc, ưu tiên hướng lên
      const el = Math.max(-1.2, Math.min(1.45, base + de)), ce = Math.cos(el);
      d.set(f.x * ce, Math.sin(el), f.z * ce);
      for (let t = 6; t < 95; t += 1.5) {
        p.copy(o).addScaledVector(d, t);
        let hit = W.solidAt(p.x, p.y, p.z);
        if (!hit) for (const r of W.nearResources(p.x, p.z, 1.2)) if (r.kind === 'tree' && p.y < r.y + 6) { hit = true; break; }
        if (hit) {
          P.grap = { t: p.clone(), L: Math.max(7, t) };
          P.st -= 6; G.audio.sfx('grapple');
          if (P.grounded) { P.vel.y = Math.max(P.vel.y, 7); P.grounded = false; }
          return;
        }
      }
    }
    G.toast('Không có điểm bám phía trước'); P.grapCd = 0.3;
  }
  function release(boost) {
    P.grap = null; P.grapCd = 0.12;
    if (boost && P.vel.y > -3) P.vel.y += 3;
  }

  P.update = dt => {
    C.poll();
    const W = G.world, S = G.rpg.stats();
    const groundAt = (x, z, y) => Math.max(W.surfaceAt(x, z, y), W.WATER - 0.3);
    if (P.invuln > 0) P.invuln -= dt;
    if (P.grapCd > 0) P.grapCd -= dt;
    // Camera: độ nhạy + vuốt/joystick + đảo trục
    const cfg = G.cfg, ddx = C.dx, ddy = C.dy; C.dx = C.dy = 0;
    const yawIn = (ddx * 0.0045 + C.lx * 2.8 * dt) * cfg.sens;
    const pitchIn = (ddy * 0.0045 + C.ly * 1.6 * dt) * cfg.sens * (cfg.invY ? -1 : 1);
    P.yaw -= yawIn;
    if (P.view === 'fp') P.fpPitch = Math.min(1.35, Math.max(-1.35, P.fpPitch - pitchIn));
    else P.pitch = Math.min(1.2, Math.max(-0.35, P.pitch + pitchIn));

    if (!P.dead) {
      if (C.press('menu')) G.rpg.toggle();
      if (C.press('view')) P.setView(P.view === 'fp' ? 'tp' : 'fp');
      if (C.press('heal')) G.rpg.usePotion();
      if (C.press('attack')) G.combat.attack();
      if (C.press('spell')) G.combat.cast();
      if (C.press('grapple')) {
        if (P.grap && cfg.swingToggle) release(true);
        else if (!P.grap && P.grapCd <= 0 && P.st >= 6) startSwing();
      }
    } else C.pressed = {};
    if (P.grap && (P.dead || (!cfg.swingToggle && !C.held.grapple))) release(true);

    const f = P.fwd(), right = new V(-f.z, 0, f.x);
    const mv = P.dead ? { x: 0, y: 0 } : { x: C.mx, y: C.my };
    const mag = Math.min(1, Math.hypot(mv.x, mv.y));
    const dir = new V().addScaledVector(f, -mv.y).addScaledVector(right, mv.x);
    if (dir.lengthSq() > 0) dir.normalize();

    P.gliding = !P.dead && C.held.glide && !P.grounded && P.vel.y < 0 && P.st > 0 && !P.grap;
    if (C.press('jump') && P.grounded && P.st >= 8 && !P.dead) { P.vel.y = 10; P.st -= 8; P.grounded = false; G.audio.sfx('jump'); }

    const inWater = W.heightAt(P.pos.x, P.pos.z) < W.WATER;
    if (P.gliding) {
      const sp = Math.max(7.5 * mag, 6) * 1.8; if (mag < 0.1) dir.copy(f);
      const k = Math.min(1, dt * 3);
      P.vel.x += (dir.x * sp - P.vel.x) * k; P.vel.z += (dir.z * sp - P.vel.z) * k;
    } else if (P.grap || !P.grounded) {
      // Trên không / đang đu: giữ đà, chỉ điều hướng nhẹ
      const lim = P.grap ? 24 : 9, along = P.vel.x * dir.x + P.vel.z * dir.z;
      if (mag > 0.05 && along < lim) { const a = (P.grap ? 22 : 16) * mag * dt; P.vel.x += dir.x * a; P.vel.z += dir.z * a; }
      const drag = Math.max(0, 1 - (P.grap ? 0.04 : 0.12) * dt); P.vel.x *= drag; P.vel.z *= drag;
    } else {
      const sp = 7.5 * mag * (inWater ? 0.55 : 1), k = Math.min(1, dt * 12);
      P.vel.x += (dir.x * sp - P.vel.x) * k; P.vel.z += (dir.z * sp - P.vel.z) * k;
    }

    if (P.grap) { P.vel.y -= 22 * dt; P.st -= 3 * dt; if (P.st <= 0) release(false); }
    else if (P.gliding) { P.vel.y = Math.max(P.vel.y - 8 * dt, -2.5); P.st -= 10 * dt; if (Math.random() < dt * 3) G.audio.sfx('glide'); }
    else P.vel.y -= 26 * dt;
    P.vel.y = Math.max(P.vel.y, -60);

    // Di chuyển ngang: chặn bởi nhà và sườn dốc
    const dx = P.vel.x * dt, dz = P.vel.z * dt, dd = Math.hypot(dx, dz), py = P.pos.y;
    const ok = (nx, nz) => {
      if (W.blocked(nx, nz, py)) return false;
      const g = Math.max(W.heightAt(nx, nz), W.WATER - 0.3);
      return g <= py + 0.6 || g - py <= dd * 1.5;
    };
    if (ok(P.pos.x + dx, P.pos.z + dz)) { P.pos.x += dx; P.pos.z += dz; }
    else if (ok(P.pos.x + dx, P.pos.z)) { P.pos.x += dx; P.vel.z = 0; }
    else if (ok(P.pos.x, P.pos.z + dz)) { P.pos.z += dz; P.vel.x = 0; }
    else { P.vel.x = 0; P.vel.z = 0; }
    P.pos.y += P.vel.y * dt;

    // Dây tơ căng: con lắc quanh điểm bám
    if (P.grap) {
      const g = P.grap; g.L = Math.max(5, g.L - 3 * dt);
      const c = new V(P.pos.x, P.pos.y + 1.4, P.pos.z), d = c.clone().sub(g.t), dist = d.length();
      if (dist > g.L) {
        d.divideScalar(dist); c.copy(g.t).addScaledVector(d, g.L);
        P.pos.set(c.x, c.y - 1.4, c.z);
        const vr = P.vel.dot(d); if (vr > 0) P.vel.addScaledVector(d, -vr);
      }
    }

    // Va chạm tài nguyên (cây, đá)
    for (const r of W.nearResources(P.pos.x, P.pos.z, 0.6)) {
      if (P.pos.y > r.y + 2.5) continue;
      const ax = P.pos.x - r.x, az = P.pos.z - r.z, d = Math.hypot(ax, az) || 0.01, minD = r.r + 0.45;
      if (d < minD) { P.pos.x = r.x + ax / d * minD; P.pos.z = r.z + az / d * minD; }
    }

    const gr = groundAt(P.pos.x, P.pos.z, py);
    if (P.pos.y <= gr) {
      if (P.vel.y < -30 && !P.gliding) P.hurt((-P.vel.y - 30) * 2.5);
      P.pos.y = gr; if (P.vel.y < 0) P.vel.y = 0; P.grounded = true;
    } else P.grounded = P.pos.y - gr < 0.3 && P.vel.y <= 0;

    P.speedH = Math.hypot(P.vel.x, P.vel.z);
    if (!P.gliding && !P.grap) P.st = Math.min(S.maxSt, P.st + 16 * dt);
    P.mp = Math.min(S.maxMp, P.mp + (3 + G.rpg.d.sk.mana * 0.5) * dt);
    if (!P.dead) P.hp = Math.min(S.maxHp, P.hp + 0.6 * dt);
    P.st = Math.max(0, P.st);

    // Mô hình + hoạt ảnh
    const sw = G.combat.swingP;
    let ta = P.face;
    if (sw >= 0) ta = Math.atan2(f.x, f.z); else if (P.speedH > 0.8) ta = Math.atan2(P.vel.x, P.vel.z);
    let da = ta - P.face; while (da > Math.PI) da -= 6.283; while (da < -Math.PI) da += 6.283;
    P.face += da * Math.min(1, dt * 12);
    P.anim += dt * (4 + P.speedH * 1.1);
    model.position.copy(P.pos); model.rotation.y = P.face; model.visible = !P.dead && P.view === 'tp';
    wing.visible = P.gliding;
    animateCharacter(model, P.anim, P.grounded ? P.speedH : 0, sw, P.gliding || !!P.grap);
    if (P.grap) {
      line.visible = true;
      const a = line.geometry.attributes.position; a.setXYZ(0, P.pos.x, P.pos.y + 1.4, P.pos.z); a.setXYZ(1, P.grap.t.x, P.grap.t.y, P.grap.t.z); a.needsUpdate = true;
    } else line.visible = false;

    // Camera
    const cam = G.camera;
    if (P.view === 'fp') {
      const bob = P.grounded ? Math.sin(P.anim) * Math.min(1, P.speedH / 6) * 0.05 : 0;
      cam.rotation.order = 'YXZ';
      cam.position.set(P.pos.x, P.pos.y + 1.7 + bob, P.pos.z);
      cam.rotation.set(P.fpPitch, P.yaw, 0);
      if (sw >= 0) { vm.rotation.x = 1.0 - sw * 1.6; vm.rotation.z = 0.5 - sw; vm.position.x = 0.34 - sw * 0.12; }
      else { vm.rotation.x = 0.3; vm.rotation.z = 0; vm.position.x = 0.34; }
      vm.position.y = -0.32 + bob * 0.8; vm.visible = !P.dead;
    } else {
      vm.visible = false;
      const t = new V(P.pos.x, P.pos.y + 1.6, P.pos.z), cp = Math.cos(P.pitch);
      cam.position.set(t.x + Math.sin(P.yaw) * cp * P.dist, t.y + Math.sin(P.pitch) * P.dist, t.z + Math.cos(P.yaw) * cp * P.dist);
      const gh = W.surfaceAt(cam.position.x, cam.position.z, cam.position.y) + 1;
      if (cam.position.y < gh) cam.position.y = gh;
      cam.lookAt(t);
    }
    // Hiệu ứng tốc độ: mở rộng góc nhìn khi bay nhanh
    const spd = Math.hypot(P.vel.x, P.vel.y, P.vel.z), tf = P.baseFov + Math.min(14, Math.max(0, spd - 12) * 0.4);
    if (Math.abs(cam.fov - tf) > 0.2) { cam.fov += (tf - cam.fov) * Math.min(1, dt * 6); cam.updateProjectionMatrix(); }
  };
  return P;
}
