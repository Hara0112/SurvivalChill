import * as THREE from 'three';
import { mulberry32 } from './world.js';

const lam = c => new THREE.MeshLambertMaterial({ color: c });
const bx = (w, h, d, m) => new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);

function buildWolf() {
  const g = new THREE.Group(), m = lam(0x77777f), dk = lam(0x333338);
  const body = bx(0.7, 0.6, 1.5, m); body.position.y = 0.75;
  const head = bx(0.5, 0.45, 0.55, m); head.position.set(0, 0.95, 0.95);
  const snout = bx(0.25, 0.22, 0.35, dk); snout.position.set(0, 0.88, 1.3);
  const tail = bx(0.18, 0.18, 0.7, dk); tail.position.set(0, 0.95, -1.0); tail.rotation.x = 0.5;
  g.add(body, head, snout, tail);
  [[-0.25, 0.7], [0.25, 0.7], [-0.25, -0.65], [0.25, -0.65]].forEach(([x, z]) => { const l = bx(0.16, 0.5, 0.16, dk); l.position.set(x, 0.25, z); g.add(l); });
  return { g, mats: [m, dk] };
}
function buildWraith() {
  const g = new THREE.Group(), m = lam(0x3a1f55), eye = new THREE.MeshBasicMaterial({ color: 0xff44ff });
  const cloak = new THREE.Mesh(new THREE.ConeGeometry(0.7, 2.3, 7), m); cloak.position.y = 1.15;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 6), m); head.position.y = 2.3;
  const e1 = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 4), eye), e2 = e1.clone();
  e1.position.set(-0.12, 2.35, 0.3); e2.position.set(0.12, 2.35, 0.3);
  g.add(cloak, head, e1, e2);
  return { g, mats: [m] };
}
function buildGolem() {
  const g = new THREE.Group(), m = lam(0x55525c), c = new THREE.MeshBasicMaterial({ color: 0xb07cff });
  const body = bx(2.4, 2.6, 1.6, m); body.position.y = 2.8;
  const head = bx(1.2, 1.0, 1.1, m); head.position.y = 4.6;
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.5), c); core.position.set(0, 3, 0.85);
  const aL = bx(0.8, 2.6, 0.8, m), aR = bx(0.8, 2.6, 0.8, m); aL.position.set(-1.7, 2.6, 0); aR.position.set(1.7, 2.6, 0);
  const lL = bx(0.9, 1.5, 0.9, m), lR = bx(0.9, 1.5, 0.9, m); lL.position.set(-0.7, 0.75, 0); lR.position.set(0.7, 0.75, 0);
  g.add(body, head, core, aL, aR, lL, lR);
  g.traverse(o => { if (o.isMesh) o.castShadow = true; });
  return { g, mats: [m] };
}

const TYPES = {
  wolf:   { name: 'Sói hoang', hp: 34, spd: 6.8, dmg: 9, range: 1.9, aggro: 24, xp: 14, size: 0.8, build: buildWolf, loot: { hide: [1, 2], meat: [0, 1] } },
  wraith: { name: 'Bóng ma Shroud', hp: 60, spd: 3.6, dmg: 14, range: 1.8, aggro: 20, xp: 24, size: 1.2, build: buildWraith, loot: { crystal: [1, 2] }, float: true },
  golem:  { name: 'Golem Cổ Đại (Trùm)', hp: 650, spd: 3.2, dmg: 28, range: 4.2, aggro: 60, xp: 220, size: 2.5, build: buildGolem, loot: { crystal: [8, 12], core: [1, 1], stone: [6, 10] }, boss: true }
};

export function createEnemies(G) {
  const V = THREE.Vector3;
  const E = { list: [], active: new Map() };
  let spawnT = 2, bossT = 0;
  const defeated = new Set(G.rpg.d.defeated);

  function spawn(type, x, z, key) {
    const T = TYPES[type], b = T.build();
    G.scene.add(b.g);
    const e = { type, T, mesh: b.g, mats: b.mats, pos: new V(x, G.world.heightAt(x, z), z), hp: T.hp, max: T.hp, cd: 1, size: T.size, kb: new V(), flash: 0, key, slam: -1, slamCd: 3, dead: false };
    b.mats.forEach(m => m.userData.base = m.color.getHex());
    E.list.push(e);
    if (T.boss) {
      const arena = new THREE.Group();
      const pm = lam(0x2e2b36);
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * 6.283, p = bx(1.2, 7, 1.2, pm);
        const px = x + Math.cos(a) * 14, pz = z + Math.sin(a) * 14;
        p.position.set(px, G.world.heightAt(px, pz) + 3.5, pz); p.castShadow = true; arena.add(p);
      }
      G.scene.add(arena); e.arena = arena;
      G.toast('Một Trùm xuất hiện: ' + T.name);
    }
    return e;
  }
  function remove(e) {
    G.scene.remove(e.mesh);
    e.mesh.traverse(o => { if (o.isMesh) o.geometry.dispose(); });
    e.mats.forEach(m => m.dispose());
    if (e.arena) { G.scene.remove(e.arena); e.arena.traverse(o => { if (o.isMesh) { o.geometry.dispose(); o.material.dispose(); } }); }
    if (e.key) E.active.delete(e.key);
    E.list.splice(E.list.indexOf(e), 1);
  }

  E.hurt = (e, dmg, dir, crit) => {
    if (e.dead) return;
    e.hp -= dmg; e.flash = 0.12;
    e.kb.set(dir.x, 0, dir.z).multiplyScalar(e.T.boss ? 1.5 : 7);
    G.combat.burst(new V(e.pos.x, e.pos.y + e.size, e.pos.z), crit ? 0xffee55 : 0xff4444, crit ? 16 : 8, 4, 0.4);
    if (e.hp <= 0) {
      e.dead = true;
      const T = e.T;
      for (const k in T.loot) { const [a, b] = T.loot[k], n = a + Math.floor(Math.random() * (b - a + 1)); if (n > 0) G.rpg.give(k, n); }
      G.rpg.addXp(T.xp);
      G.combat.burst(new V(e.pos.x, e.pos.y + e.size, e.pos.z), T.boss ? 0xb07cff : 0xaa66ff, T.boss ? 80 : 24, 8, 1);
      if (T.boss) { G.rpg.d.sp += 2; G.toast('Đã hạ Trùm! +2 điểm kỹ năng'); if (e.key) { defeated.add(e.key); G.rpg.d.defeated = [...defeated]; } G.rpg.save(); }
      remove(e);
    }
  };

  const bossSite = (ix, iz) => {
    const r = mulberry32(((ix * 92821) ^ (iz * 68917) ^ G.world.seed) >>> 0);
    if (r() < 0.5) return null;
    const x = (ix + 0.15 + r() * 0.7) * 320, z = (iz + 0.15 + r() * 0.7) * 320, h = G.world.heightAt(x, z);
    if (G.world.cityDist(x, z) < 260 || h < 0 || h > 30) return null;
    return { x, z, key: ix + ',' + iz };
  };
  E.bossNear = () => { for (const e of E.list) if (e.T.boss && Math.hypot(e.pos.x - G.player.pos.x, e.pos.z - G.player.pos.z) < 70) return e; return null; };

  E.update = dt => {
    const P = G.player;
    spawnT -= dt; bossT -= dt;
    if (spawnT <= 0) {
      spawnT = 2.2;
      const normals = E.list.filter(e => !e.T.boss).length;
      if (normals < 14 && !P.dead) {
        const a = Math.random() * 6.283, d = 38 + Math.random() * 30, x = P.pos.x + Math.cos(a) * d, z = P.pos.z + Math.sin(a) * d;
        const h = G.world.heightAt(x, z), s = G.world.shroudAt(x, z);
        if (h > -3 && G.world.cityDist(x, z) > 60) {
          if (s > 0.3) spawn('wraith', x, z);
          else if (G.isNight || Math.random() < 0.25) spawn('wolf', x, z);
        }
      }
    }
    if (bossT <= 0) {
      bossT = 1.5;
      const ci = Math.floor(P.pos.x / 320), cj = Math.floor(P.pos.z / 320);
      for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
        const s = bossSite(ci + i, cj + j);
        if (s && !defeated.has(s.key) && !E.active.has(s.key) && Math.hypot(s.x - P.pos.x, s.z - P.pos.z) < 110) E.active.set(s.key, spawn('golem', s.x, s.z, s.key));
      }
    }
    for (let i = E.list.length - 1; i >= 0; i--) {
      const e = E.list[i], T = e.T;
      const dx = P.pos.x - e.pos.x, dz = P.pos.z - e.pos.z, dist = Math.hypot(dx, dz);
      if (dist > (T.boss ? 260 : 120) || G.world.cityDist(e.pos.x, e.pos.z) < 15) { remove(e); continue; }
      if (e.cd > 0) e.cd -= dt;
      let mvx = 0, mvz = 0;
      if (!P.dead && dist < T.aggro) {
        if (dist > T.range * 0.8) { mvx = dx / dist; mvz = dz / dist; }
        if (e.slam >= 0) { mvx = mvz = 0; e.slam -= dt; if (e.slam < 0) { // đòn dập đất của Trùm
            G.audio.sfx('slam'); G.combat.burst(new V(e.pos.x, e.pos.y + 0.3, e.pos.z), 0xaa8855, 40, 10, 0.6);
            if (Math.hypot(P.pos.x - e.pos.x, P.pos.z - e.pos.z) < 8 && P.grounded) P.hurt(T.dmg * 1.5);
          } }
        else if (T.boss && e.slamCd > 0) e.slamCd -= dt;
        else if (T.boss && dist < 9) { e.slam = 0.7; e.slamCd = 4; }
        if (dist < T.range + 0.5 && e.cd <= 0 && e.slam < 0) { e.cd = T.boss ? 1.6 : 1.1; P.hurt(T.dmg * (0.9 + Math.random() * 0.2)); }
      }
      e.pos.x += (mvx * T.spd + e.kb.x) * dt; e.pos.z += (mvz * T.spd + e.kb.z) * dt;
      e.kb.multiplyScalar(Math.max(0, 1 - dt * 6));
      const gy = Math.max(G.world.heightAt(e.pos.x, e.pos.z), G.world.WATER - 0.3);
      e.pos.y += (gy + (T.float ? 0.6 + Math.sin(performance.now() / 400 + i) * 0.25 : 0) - e.pos.y) * Math.min(1, dt * 12);
      e.mesh.position.copy(e.pos);
      if (dist < T.aggro) e.mesh.rotation.y = Math.atan2(dx, dz);
      if (e.slam >= 0) e.mesh.position.y += Math.sin(e.slam * 10) * 0.1;
      if (e.flash > 0) { e.flash -= dt; e.mats.forEach(m => m.emissive.setHex(e.flash > 0 ? 0xff3333 : 0x000000)); }
    }
  };
  return E;
}
