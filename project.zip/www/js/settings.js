// Bảng cài đặt: camera, nút cảm ứng (kích thước, độ mờ, kéo thả vị trí), đồ họa
const DEF = { sens: 1, invY: false, camMode: 'swipe', swingToggle: true, btnScale: 1, btnAlpha: 1, shadows: true, res: 2, layout: {} };
const RES = [0.75, 1, 1.5];

export function loadConfig() {
  try { return Object.assign({}, DEF, JSON.parse(localStorage.getItem('shroud_cfg') || '{}')); } catch (e) { return Object.assign({}, DEF); }
}

export function createSettings(G) {
  const cfg = G.cfg, $ = G.$;
  const ids = ['bAtk', 'bJump', 'bSpell', 'bGrap', 'bGlide', 'bHeal', 'bMenu', 'bView', 'bSet'];
  const save = () => { try { localStorage.setItem('shroud_cfg', JSON.stringify(cfg)); } catch (e) { /* bỏ qua */ } };
  const place = (el, x, y) => { el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.right = 'auto'; el.style.bottom = 'auto'; el.style.translate = '-50% -50%'; };

  function applyStyle() { const r = document.documentElement.style; r.setProperty('--bs', cfg.btnScale); r.setProperty('--ba', cfg.btnAlpha); }
  function applyLayout() {
    for (const id of ids) {
      const el = $(id), p = cfg.layout[id];
      if (p) place(el, p.x * innerWidth, p.y * innerHeight);
      else ['left', 'top', 'right', 'bottom', 'translate'].forEach(k => { el.style[k] = ''; });
    }
  }
  function applyGfx() {
    G.sun.castShadow = cfg.shadows;
    G.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, RES[cfg.res]));
    G.renderer.setSize(innerWidth, innerHeight);
  }
  applyStyle(); applyLayout(); applyGfx();
  addEventListener('resize', applyLayout);

  // ----- Chế độ kéo thả vị trí nút -----
  let editing = false;
  function setEdit(v) {
    editing = v; document.body.classList.toggle('editing', v);
    $('editBar').classList.toggle('hidden', !v);
    if (v) $('settings').classList.add('hidden');
  }
  ids.forEach(id => {
    const el = $(id); let pid = null, lx = 0, ly = 0;
    el.addEventListener('pointerdown', e => {
      if (!editing) return;
      e.stopImmediatePropagation(); e.preventDefault(); pid = e.pointerId; el.setPointerCapture(pid);
    }, true);
    el.addEventListener('pointermove', e => {
      if (!editing || e.pointerId !== pid) return;
      lx = Math.max(30, Math.min(innerWidth - 30, e.clientX)); ly = Math.max(30, Math.min(innerHeight - 30, e.clientY));
      place(el, lx, ly);
    });
    el.addEventListener('pointerup', e => {
      if (!editing || e.pointerId !== pid) return;
      pid = null; if (lx) { cfg.layout[id] = { x: lx / innerWidth, y: ly / innerHeight }; save(); }
    });
  });
  $('editDone').onclick = () => { setEdit(false); };
  $('editReset').onclick = () => { cfg.layout = {}; applyLayout(); save(); };

  // ----- Bảng cài đặt -----
  const seg = (key, val, label) => `<button data-s="${key}:${val}" class="${String(cfg[key]) === String(val) ? 'on' : ''}">${label}</button>`;
  function render() {
    $('sbody').innerHTML = `
      <div class="sh">Camera</div>
      <div class="srow"><span>Kiểu xoay</span><span class="seg">${seg('camMode', 'swipe', 'Vuốt')}${seg('camMode', 'stick', 'Joystick')}</span></div>
      <div class="srow"><span>Độ nhạy</span><input type="range" id="rSens" min="0.3" max="2.5" step="0.05" value="${cfg.sens}"><b id="vSens">${cfg.sens.toFixed(2)}</b></div>
      <div class="srow"><span>Đảo trục dọc</span><span class="seg">${seg('invY', 'false', 'Tắt')}${seg('invY', 'true', 'Bật')}</span></div>
      <div class="srow"><span>Đu tơ 🪝</span><span class="seg">${seg('swingToggle', 'true', 'Chạm bật/tắt')}${seg('swingToggle', 'false', 'Giữ nút')}</span></div>
      <div class="sh">Nút cảm ứng</div>
      <div class="srow"><span>Kích thước</span><input type="range" id="rBs" min="0.7" max="1.5" step="0.05" value="${cfg.btnScale}"><b id="vBs">${cfg.btnScale.toFixed(2)}</b></div>
      <div class="srow"><span>Độ rõ</span><input type="range" id="rBa" min="0.3" max="1" step="0.05" value="${cfg.btnAlpha}"><b id="vBa">${cfg.btnAlpha.toFixed(2)}</b></div>
      <div class="srow"><button data-s="edit" class="act">✋ Kéo thả vị trí nút</button><button data-s="reset" class="act">Đặt lại vị trí</button></div>
      <div class="sh">Đồ họa</div>
      <div class="srow"><span>Bóng đổ</span><span class="seg">${seg('shadows', 'true', 'Bật')}${seg('shadows', 'false', 'Tắt')}</span></div>
      <div class="srow"><span>Độ phân giải</span><span class="seg">${seg('res', 0, 'Thấp')}${seg('res', 1, 'Vừa')}${seg('res', 2, 'Cao')}</span></div>`;
  }
  $('bSet').addEventListener('click', () => {
    if (editing) return;
    const s = $('settings'); s.classList.toggle('hidden');
    if (!s.classList.contains('hidden')) render();
  });
  $('sClose').onclick = () => $('settings').classList.add('hidden');
  $('sbody').addEventListener('input', e => {
    const v = parseFloat(e.target.value);
    if (e.target.id === 'rSens') { cfg.sens = v; $('vSens').textContent = v.toFixed(2); }
    else if (e.target.id === 'rBs') { cfg.btnScale = v; $('vBs').textContent = v.toFixed(2); applyStyle(); }
    else if (e.target.id === 'rBa') { cfg.btnAlpha = v; $('vBa').textContent = v.toFixed(2); applyStyle(); }
    save();
  });
  $('sbody').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const [k, v] = b.dataset.s.split(':');
    if (k === 'edit') return setEdit(true);
    if (k === 'reset') { cfg.layout = {}; applyLayout(); save(); return; }
    if (k === 'camMode') cfg.camMode = v;
    else if (k === 'invY') cfg.invY = v === 'true';
    else if (k === 'swingToggle') cfg.swingToggle = v === 'true';
    else if (k === 'shadows') { cfg.shadows = v === 'true'; applyGfx(); }
    else if (k === 'res') { cfg.res = parseInt(v, 10); applyGfx(); }
    save(); render();
  });
}
